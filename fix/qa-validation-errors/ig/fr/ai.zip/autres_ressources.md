# Autres Ressources - FR Document Core (CDA) v0.1.0

## Autres Ressources

* [Téléchargements et usage](./downloads.md)
* [Spécifications FHIR](http://hl7.org/fhir/R5/index.html)
* [Site de l'ANS](https://esante.gouv.fr/)

