# CDA - assignedCustodian - FR Document Core (CDA) v0.1.0

## Modèle logique: CDA - assignedCustodian 

 
L'élément de l'en-tête du CDA assignedCustodian contient l’élément representedCustodianOrganization caractérisant la structure conservant le document. 

**Utilisations:**

* Utilise ce/t/te Profil de modèle logique: [CDA - custodian](StructureDefinition-fr-cda-custodian.md)

Vous pouvez également vérifier [les usages dans le FHIR IG Statistics](https://packages2.fhir.org/xig/ans.cda.fr.document-core|current/StructureDefinition/fr-cda-assigned-custodian)

### Vues formelles du contenu du profil

 [Description des profils, des différentiels, des instantanés et de leurs représentations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Tableau différentiel (differential)](#tabs-diff) 
*  [Tableau récapitulatif (snapshot)](#tabs-snap) 
*  [Statistiques/Références](#tabs-summ) 
*  [Tous](#tabs-all) 

Cette structure est dérivée de [AssignedCustodian](http://hl7.org/cda/stds/core/2.0.3-sd/StructureDefinition-AssignedCustodian.html) 

#### Bindings terminologiques

#### Contraintes

Cette structure est dérivée de [AssignedCustodian](http://hl7.org/cda/stds/core/2.0.3-sd/StructureDefinition-AssignedCustodian.html) 

** Résumé **

Interdit : 3 éléments

**Structures**

Cette structure fait référence à ces autres structures:

* [CDA - representedCustodianOrganization (https://interop.esante.gouv.fr/ig/cda/document-core/StructureDefinition/fr-cda-represented-custodian-organization|0.1.0)](StructureDefinition-fr-cda-represented-custodian-organization.md)

 **Vue différentielle** 

Cette structure est dérivée de [AssignedCustodian](http://hl7.org/cda/stds/core/2.0.3-sd/StructureDefinition-AssignedCustodian.html) 

 **Vue d'ensembleView** 

#### Bindings terminologiques

#### Contraintes

Cette structure est dérivée de [AssignedCustodian](http://hl7.org/cda/stds/core/2.0.3-sd/StructureDefinition-AssignedCustodian.html) 

** Résumé **

Interdit : 3 éléments

**Structures**

Cette structure fait référence à ces autres structures:

* [CDA - representedCustodianOrganization (https://interop.esante.gouv.fr/ig/cda/document-core/StructureDefinition/fr-cda-represented-custodian-organization|0.1.0)](StructureDefinition-fr-cda-represented-custodian-organization.md)

 

Autres représentations du profil : [CSV](../StructureDefinition-fr-cda-assigned-custodian.csv), [Excel](../StructureDefinition-fr-cda-assigned-custodian.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "fr-cda-assigned-custodian",
  "extension" : [{
    "url" : "http://hl7.org/fhir/tools/StructureDefinition/logical-target",
    "_valueBoolean" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/data-absent-reason",
        "valueCode" : "not-applicable"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/tools/StructureDefinition/xml-namespace",
    "valueUri" : "urn:hl7-org:v3"
  },
  {
    "url" : "http://hl7.org/fhir/tools/StructureDefinition/xml-name",
    "valueString" : "assignedCustodian"
  },
  {
    "url" : "http://hl7.org/fhir/tools/StructureDefinition/logical-container",
    "valueUri" : "http://hl7.org/cda/stds/core/StructureDefinition/ClinicalDocument"
  },
  {
    "url" : "http://hl7.org/fhir/tools/StructureDefinition/type-profile-style",
    "valueCode" : "cda"
  }],
  "url" : "https://interop.esante.gouv.fr/ig/cda/document-core/StructureDefinition/fr-cda-assigned-custodian",
  "version" : "0.1.0",
  "name" : "FRCDAAssignedCustodian",
  "title" : "CDA - assignedCustodian",
  "status" : "draft",
  "date" : "2026-09-08T08:30:09+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "L'élément de l'en-tête du CDA assignedCustodian contient l’élément representedCustodianOrganization caractérisant la structure conservant le document.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "fhirVersion" : "5.0.0",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "logical",
  "abstract" : false,
  "type" : "http://hl7.org/cda/stds/core/StructureDefinition/AssignedCustodian",
  "baseDefinition" : "http://hl7.org/cda/stds/core/StructureDefinition/AssignedCustodian|2.0.3-sd",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "AssignedCustodian",
      "path" : "AssignedCustodian"
    },
    {
      "id" : "AssignedCustodian.typeId.nullFlavor",
      "path" : "AssignedCustodian.typeId.nullFlavor",
      "max" : "0"
    },
    {
      "id" : "AssignedCustodian.typeId.assigningAuthorityName",
      "path" : "AssignedCustodian.typeId.assigningAuthorityName",
      "max" : "0"
    },
    {
      "id" : "AssignedCustodian.typeId.displayable",
      "path" : "AssignedCustodian.typeId.displayable",
      "max" : "0"
    },
    {
      "id" : "AssignedCustodian.representedCustodianOrganization",
      "path" : "AssignedCustodian.representedCustodianOrganization",
      "short" : "Structure",
      "type" : [{
        "code" : "http://hl7.org/cda/stds/core/StructureDefinition/CustodianOrganization",
        "profile" : ["https://interop.esante.gouv.fr/ig/cda/document-core/StructureDefinition/fr-cda-represented-custodian-organization|0.1.0"]
      }]
    }]
  }
}

```
